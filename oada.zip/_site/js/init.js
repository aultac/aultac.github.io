$(document).foundation();
svgeezy.init("nocheck","png");
$(window).load(function(){
      $("#sticker").sticky({ topSpacing: 50 });
    });